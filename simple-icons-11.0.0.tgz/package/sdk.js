var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var stdin_exports = {};
__export(stdin_exports, {
  SVG_PATH_REGEX: () => SVG_PATH_REGEX,
  URL_REGEX: () => URL_REGEX,
  collator: () => collator,
  getDirnameFromImportMeta: () => getDirnameFromImportMeta,
  getIconDataPath: () => getIconDataPath,
  getIconSlug: () => getIconSlug,
  getIconsData: () => getIconsData,
  getIconsDataString: () => getIconsDataString,
  getThirdPartyExtensions: () => getThirdPartyExtensions,
  htmlFriendlyToTitle: () => htmlFriendlyToTitle,
  normalizeColor: () => normalizeColor,
  normalizeNewlines: () => normalizeNewlines,
  slugToVariableName: () => slugToVariableName,
  svgToPath: () => svgToPath,
  titleToHtmlFriendly: () => titleToHtmlFriendly,
  titleToSlug: () => titleToSlug
});
module.exports = __toCommonJS(stdin_exports);
var import_node_path = __toESM(require("node:path"));
var import_promises = __toESM(require("node:fs/promises"));
var import_node_url = require("node:url");
const import_meta = {};
const TITLE_TO_SLUG_REPLACEMENTS = {
  "+": "plus",
  ".": "dot",
  "&": "and",
  \u0111: "d",
  \u0127: "h",
  \u0131: "i",
  \u0138: "k",
  \u0140: "l",
  \u0142: "l",
  \u00DF: "ss",
  \u0167: "t"
};
const TITLE_TO_SLUG_CHARS_REGEX = RegExp(
  `[${Object.keys(TITLE_TO_SLUG_REPLACEMENTS).join("")}]`,
  "g"
);
const TITLE_TO_SLUG_RANGE_REGEX = /[^a-z0-9]/g;
const URL_REGEX = /^https:\/\/[^\s"']+$/;
const SVG_PATH_REGEX = /^m[-mzlhvcsqtae0-9,. ]+$/i;
const getDirnameFromImportMeta = (importMetaUrl) => import_node_path.default.dirname((0, import_node_url.fileURLToPath)(importMetaUrl));
const getIconSlug = (icon) => icon.slug || titleToSlug(icon.title);
const svgToPath = (svg) => svg.split('"', 8)[7];
const titleToSlug = (title) => title.toLowerCase().replace(
  TITLE_TO_SLUG_CHARS_REGEX,
  (char) => TITLE_TO_SLUG_REPLACEMENTS[char]
).normalize("NFD").replace(TITLE_TO_SLUG_RANGE_REGEX, "");
const slugToVariableName = (slug) => {
  const slugFirstLetter = slug[0].toUpperCase();
  return `si${slugFirstLetter}${slug.slice(1)}`;
};
const titleToHtmlFriendly = (brandTitle) => brandTitle.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/./g, (char) => {
  const charCode = char.charCodeAt(0);
  return charCode > 127 ? `&#${charCode};` : char;
});
const htmlFriendlyToTitle = (htmlFriendlyTitle) => htmlFriendlyTitle.replace(/&#([0-9]+);/g, (_, num) => String.fromCodePoint(parseInt(num))).replace(
  /&(quot|amp|lt|gt);/g,
  (_, ref) => ({ quot: '"', amp: "&", lt: "<", gt: ">" })[ref]
);
const getIconDataPath = (rootDir = getDirnameFromImportMeta(import_meta.url)) => {
  return import_node_path.default.resolve(rootDir, "_data", "simple-icons.json");
};
const getIconsDataString = (rootDir = getDirnameFromImportMeta(import_meta.url)) => {
  return import_promises.default.readFile(getIconDataPath(rootDir), "utf8");
};
const getIconsData = async (rootDir = getDirnameFromImportMeta(import_meta.url)) => {
  const fileContents = await getIconsDataString(rootDir);
  return JSON.parse(fileContents).icons;
};
const normalizeNewlines = (text) => {
  return text.replace(/\r\n/g, "\n");
};
const normalizeColor = (text) => {
  let color = text.replace("#", "").toUpperCase();
  if (color.length < 6) {
    color = [...color.slice(0, 3)].map((x) => x.repeat(2)).join("");
  } else if (color.length > 6) {
    color = color.slice(0, 6);
  }
  return color;
};
const getThirdPartyExtensions = async (readmePath = import_node_path.default.join(
  getDirnameFromImportMeta(import_meta.url),
  "README.md"
)) => normalizeNewlines(await import_promises.default.readFile(readmePath, "utf8")).split("## Third-Party Extensions\n\n")[1].split("\n\n", 1)[0].split("\n").slice(2).map((line) => {
  let [module2, author] = line.split(" | ");
  module2 = module2.split('<img src="')[0];
  return {
    module: {
      name: /\[(.+)\]/.exec(module2)[1],
      url: /\((.+)\)/.exec(module2)[1]
    },
    author: {
      name: /\[(.+)\]/.exec(author)[1],
      url: /\((.+)\)/.exec(author)[1]
    }
  };
});
const collator = new Intl.Collator("en", {
  usage: "search",
  caseFirst: "upper"
});
